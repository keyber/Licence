package graphique;

class ColorNotFoundException extends Exception {
	
	public ColorNotFoundException() {
		super();
	}

}